Publications
************

This page lists some known publications, ordered by the publication date, that might be useful in  addition to the documentation.

* `"Working on a new network transport for PulseAudio and ALSA" <https://gavv.github.io/articles/new-network-transport/>`_ *by Victor Gaydov*

* `"Roc 0.1 released: real-time streaming over the network" <https://gavv.github.io/articles/roc-0.1/>`_ *by Victor Gaydov*

* `"A step-by-step tutorial for live audio streaming with Roc" <https://gavv.github.io/articles/roc-tutorial/>`_ *by Victor Gaydov*
